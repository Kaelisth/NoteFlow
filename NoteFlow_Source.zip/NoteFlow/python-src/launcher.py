"""
NoteFlow — Python Desktop Launcher
使用 pywebview 将 HTML 应用包装为桌面窗口

安装依赖：
    pip install pywebview

打包为 exe (Windows)：
    pip install pyinstaller
    pyinstaller --onefile --windowed --name NoteFlow --add-data "NoteFlow.html;." launcher.py

打包为 exe (macOS/Linux)：
    pyinstaller --onefile --windowed --name NoteFlow --add-data "NoteFlow.html:." launcher.py
"""

import sys
import os
import webview

def get_html_path():
    """获取 NoteFlow.html 的绝对路径（兼容 PyInstaller 打包后的路径）"""
    if getattr(sys, 'frozen', False):
        # PyInstaller 打包后，文件在临时目录
        base_dir = sys._MEIPASS
    else:
        # 开发模式，文件在脚本同目录
        base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, 'NoteFlow.html')

def main():
    html_path = get_html_path()

    if not os.path.exists(html_path):
        import tkinter.messagebox as mb
        mb.showerror('NoteFlow', f'找不到 NoteFlow.html\n路径: {html_path}')
        sys.exit(1)

    window = webview.create_window(
        title='NoteFlow',
        url=f'file:///{html_path}',
        width=1200,
        height=800,
        min_size=(700, 500),
        resizable=True,
        text_select=True,
        background_color='#F5F0E8',
    )

    webview.start(
        debug=False,
        http_server=False,
    )

if __name__ == '__main__':
    main()
